#pragma once

#include "Definitions.h"
#include "SolidBody.h"

class Room: public SolidBody
{
	double			posX;
	double			posY;
	double			posZ;

	double			sizeX;
	double			sizeY;
	double			sizeZ;

	double			rotX;
	double			rotY;
	double			rotZ;

	Uint32			colBottom;
	Uint32			colTop;
	Uint32			colBack;
	Uint32			colFront;
	Uint32			colLeft;
	Uint32			colRight;

	int				txtBottom;
	int				txtTop;
	int				txtBack;
	int				txtFront;
	int				txtLeft;
	int				txtRight;

	double			txUBottom;
	double			txUTop;
	double			txUBack;
	double			txUFront;
	double			txULeft;
	double			txURight;

	bool			isBottomOn;
	bool			isTopOn;
	bool			isBackOn;
	bool			isFrontOn;
	bool			isLeftOn;
	bool			isRightOn;

public:
	Room();
	Room(double, double, double, double, double, double, double, double, double, Uint32*, int*);
	~Room();

	void setPosition(double, double, double);
	void setDimension(double, double, double);
	void setRotation(double, double, double);
	void setColour(Uint32 bottom, Uint32 top, Uint32 back, Uint32 front, Uint32 left, Uint32 right);
	void setTexture(int bottom, int top, int back, int front, int left, int right);
	void setTextureScale(double bottom, double top, double back, double front, double left, double right);
	void setSideOn(bool bottom, bool top, bool back, bool front, bool left, bool right);

	int getTotalVert();
	int getTotalPoly();

	triangle3dV* getTriangleData();
};

