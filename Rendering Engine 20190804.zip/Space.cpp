#include "Space.h"



Space::Space()
{

}


Space::~Space()
{
}

