#pragma once

#include "Definitions.h"
//#include "Sphere.h"
//#include "Cube.h"
//#include "Prism.h"
//#include "Cylinder.h"
//#include "Cone.h"
//#include "Revolved.h"

#include "SolidBody.h"
#include "SpotLight.h"

class Shapes
{
	int nEntities;
	int currentEntity;

	std::vector<SolidBody*> bodyContainer;
	std::vector<char*> textureNameContainer;
	std::vector<txt> textureDataContainer;
	std::vector<SpotLight*> lightContainer;

	triangle3dV** meshTriangles;
	txt* textures;
	vect3* spotLightPositions;
	double* spotLightIntensities;
	
public:

	Shapes();
	~Shapes();

	int getNEntities();
	int getNSpotLights();
	int* getPolyCountEntities();

	void addSolid(SolidBody*);
	void addTextureName(char*);
	void addTextureData(txt);
	void addSpotLight(SpotLight*);

	int getTotalPolyCount();
	int getPolyCount(int);

	triangle3dV** getPolyData();
	txt* getTextureData();
	vect3* getSpotLightPositions();
	double* getSpotLightIntensities();
	triangle3dV* getSupport(int* n);
};

