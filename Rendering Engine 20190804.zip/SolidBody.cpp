#include "SolidBody.h"

#include "Definitions.h"

SolidBody::SolidBody()
{
}


SolidBody::~SolidBody()
{
}
