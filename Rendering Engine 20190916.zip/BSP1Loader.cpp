#include <fstream>
#include <iostream>

#include "BSP1Loader.h"



BSP1Loader::BSP1Loader(std::string f)
{
	fileName = f;
	scale = { 1.0, 1.0, 1.0, 1.0 };
}


BSP1Loader::BSP1Loader(std::string f, vect3 s)
{
	fileName = f;
	scale = s;
}


BSP1Loader::~BSP1Loader()
{
}


void BSP1Loader::readData()
{
	std::ifstream modelFile(fileName.c_str(), std::ifstream::in | std::ifstream::binary);

	char version[4] = "";

	char offset[4] = "";
	char length[4] = "";

	lump direntry[15] = { 0, 0 };

	if (modelFile)
	{
		modelFile.read(version, 4);
		int version_no = *((int*)version);
		std::cout << version_no << std::endl;

		for (int i = 0; i < 15; i++)
		{
			modelFile.read(offset, 4);
			modelFile.read(length, 4);
			direntry[i].offset = *((int*)offset);
			direntry[i].length = *((int*)length);
			std::cout << "Offset " << i << " : " << direntry[i].offset << std::endl;
			std::cout << "Length " << i << " : " << direntry[i].length << std::endl;
		}

		/*
		*	EXTRACTING VERTICES FROM BSP FILE
		*/
		
		modelFile.seekg(direntry[3].offset, modelFile.beg);
		for (int i = 0; i < (direntry[3].length / 12); i++)
		{
			char temp_4[4] = "";

			modelFile.read(temp_4, 4);
			float vert_x = *((float*)temp_4);

			modelFile.read(temp_4, 4);
			float vert_y = *((float*)temp_4);

			modelFile.read(temp_4, 4);
			float vert_z = *((float*)temp_4);

			point3 tempPoint;
			tempPoint.P.x = (double)vert_x * scale.x;
			tempPoint.P.y = (double)vert_y * scale.y;
			tempPoint.P.z = (double)vert_z * scale.z;
			tempPoint.P.w = 1.0;
			tempPoint.colour = getColour(0, 127, 127, 255);

			vertexContainer.push_back(tempPoint);
		}
		vertexContainer.shrink_to_fit();

		/*
		*	EXTRACTING EDGES FROM BSP FILE
		*/

		modelFile.seekg(direntry[12].offset, modelFile.beg);
		for (int i = 0; i < (direntry[12].length / 4); i++)
		{
			char temp_2[2] = "";

			modelFile.read(temp_2, 2);
			unsigned short a = *((unsigned short*)temp_2);

			modelFile.read(temp_2, 2);
			unsigned short b = *((unsigned short*)temp_2);

			edge3d tempEdge;

			tempEdge.startPoint		= a;
			tempEdge.endPoint		= b;

			edgeContainer.push_back(tempEdge);
		}
		edgeContainer.shrink_to_fit();

		/*
		*	EXTRACTING LIST OF EDGES FROM BSP FILE
		*/

		modelFile.seekg(direntry[13].offset, modelFile.beg);
		for (int i = 0; i < (direntry[13].length / 4); i++)
		{
			char temp_4[4] = "";

			long tempLEdge;

			modelFile.read(temp_4, 4);
			tempLEdge = *((long*)temp_4);

			edgeListContainer.push_back(tempLEdge);
		}
		edgeListContainer.shrink_to_fit();

		/*
		*	EXTRACTING FACES FROM BSP FILE
		*/
		
		modelFile.seekg(direntry[7].offset, modelFile.beg);
		for (int i = 0; i < (direntry[7].length / 20); i++)
		{
			char temp_2[2] = "";
			char temp_4[4] = "";

			face_t tempFace;

			modelFile.read(temp_2, 2);
			tempFace.plane_id = *((unsigned short*)temp_2);

			modelFile.read(temp_2, 2);
			tempFace.side = *((unsigned short*)temp_2);

			modelFile.read(temp_4, 4);
			tempFace.ledge_id = *((long*)temp_4);

			modelFile.read(temp_2, 2);
			tempFace.ledge_num = *((unsigned short*)temp_2);

			modelFile.read(temp_2, 2);
			tempFace.texinfo_id = *((unsigned short*)temp_2);

			modelFile.read(temp_4, 4);
			tempFace.typelight = temp_4[0];
			tempFace.baselight = temp_4[1];
			tempFace.light[0] = temp_4[2];
			tempFace.light[1] = temp_4[3];

			modelFile.read(temp_4, 4);
			tempFace.lightmap = *((long*)temp_4);
		
			faceContainer.push_back(tempFace);
		}
		faceContainer.shrink_to_fit();

		/*
		*	EXTRACTING TEXTURE INFORMATION FROM BSP FILE
		*/

		modelFile.seekg(direntry[6].offset, modelFile.beg);
		for (int i = 0; i < (direntry[6].length / 40); i++)
		{
			char temp_2[2] = "";
			char temp_4[4] = "";

			surface_t tempSurface;

			modelFile.read(temp_4, 4);
			tempSurface.S.x = *((float*)temp_4);
			modelFile.read(temp_4, 4);
			tempSurface.S.y = *((float*)temp_4);
			modelFile.read(temp_4, 4);
			tempSurface.S.z = *((float*)temp_4);
			modelFile.read(temp_4, 4);
			tempSurface.distS = *((float*)temp_4);

			modelFile.read(temp_4, 4);
			tempSurface.T.x = *((float*)temp_4);
			modelFile.read(temp_4, 4);
			tempSurface.T.y = *((float*)temp_4);
			modelFile.read(temp_4, 4);
			tempSurface.T.z = *((float*)temp_4);
			modelFile.read(temp_4, 4);
			tempSurface.distT = *((float*)temp_4);

			modelFile.read(temp_4, 4);
			tempSurface.texture_id = *((unsigned long*)temp_4);

			modelFile.read(temp_4, 4);
			tempSurface.animated = *((unsigned long*)temp_4);

			surfaceContainer.push_back(tempSurface);
		}
		surfaceContainer.shrink_to_fit();
	}
	modelFile.close();

	this->calculateTriangles();
}


int	BSP1Loader::getTotalVert()
{
	return vertexContainer.size();
}


int BSP1Loader::getTotalEdge()
{
	return edgeContainer.size();
}


int BSP1Loader::getTotalPoly()
{
	/*int nFace = faceContainer.size();
	int nPoly = 0;
	for (int i = 0; i < nFace; i++)
	{
		int nEdge = faceContainer[i].ledge_num;
		nPoly += (nEdge - 2);
	}
	return nPoly;*/

	return polyContainer.size();
}


void BSP1Loader::getVertexData(point3 * v)
{
	int nVert = this->getTotalVert();
	for (int i = 0; i < nVert; i++)
	{
		v[i] = vertexContainer[i];
	}
}


void BSP1Loader::calculateTriangles()
{
	int nFace = faceContainer.size();
	for (int i = 0; i < nFace; i++)
	{
		int nEdge = faceContainer[i].ledge_num;

		unsigned short textureId = faceContainer[i].texinfo_id;
		vect3 S, T;
		S.x = surfaceContainer[textureId].S.x;		T.x = surfaceContainer[textureId].T.x;
		S.y = surfaceContainer[textureId].S.y;		T.y = surfaceContainer[textureId].T.y;
		S.z = surfaceContainer[textureId].S.z;		T.z = surfaceContainer[textureId].T.z;
		double distS, distT;
		distS = (double)surfaceContainer[textureId].distS;
		distT = (double)surfaceContainer[textureId].distT;


		unsigned short* vertIndices = new unsigned short[nEdge];
		for (int j = 0; j < nEdge; j++)
		{
			long currentEdge = edgeListContainer[faceContainer[i].ledge_id + j];
			if (currentEdge >= 0)
			{
				vertIndices[j] = edgeContainer[currentEdge].startPoint;
			}
			else
			{
				currentEdge = -currentEdge;
				vertIndices[j] = edgeContainer[currentEdge].endPoint;
			}
		}	
		for (int k = 0; k < (nEdge - 2); k++)
		{
			triangle3dV temp;
			int aIndex = vertIndices[0];
			int bIndex = vertIndices[k + 1];
			int cIndex = vertIndices[k + 2];

			temp.A = vertexContainer[aIndex].P;
			temp.B = vertexContainer[bIndex].P;
			temp.C = vertexContainer[cIndex].P;

			temp.N = unitVector(crossProduct(subVectors(temp.A, temp.B), subVectors(temp.C, temp.B)));

			temp.An = temp.Bn = temp.Cn = temp.N;

			//temp.At = temp.At = temp.At = { 0.0, 0.0 };
			temp.At.u = dotProduct(temp.A, S) + distS;
			temp.At.v = dotProduct(temp.A, T) + distT;
			temp.Bt.u = dotProduct(temp.B, S) + distS;
			temp.Bt.v = dotProduct(temp.B, T) + distT;
			temp.Ct.u = dotProduct(temp.C, S) + distS;
			temp.Ct.v = dotProduct(temp.C, T) + distT;

			//if(temp.At.u < 0){temp.At.u = 1.0 }
			//{ sampleYnew = currentTexture.h - sampleYnew % currentTexture.h; }
			temp.colour = getColour(0, 127, 127, 255);

			temp.texture = 3;

			polyContainer.push_back(temp);
		}
	}
	polyContainer.shrink_to_fit();
}


void BSP1Loader::getTriangleData_(triangle3dV* T)
{
	for (int i = 0; i < this->getTotalPoly(); i++)
	{
		T[i] = polyContainer[i];
	}
}


vect3 BSP1Loader::getPosition()
{
	return position;
}


void BSP1Loader::constructShadowVolume(vect3)
{

}


line3d BSP1Loader::getLine(unsigned int n)
{
	unsigned int nLine = this->getTotalEdge();
	if (n <= nLine)
	{
		vect3 start_point, end_point;

		unsigned short startIndex, endIndex;

		startIndex	= edgeContainer[n].startPoint;
		endIndex	= edgeContainer[n].endPoint;

		start_point = vertexContainer[startIndex].P;
		end_point	= vertexContainer[endIndex].P;

		line3d temp;

		temp.A = start_point;
		temp.B = end_point;

		temp.colour = getColour(0, 127, 127, 255);

		return temp;
	}
	else
	{
		return { (0.0, 0.0, 0.0, 1.0), (0.0, 0.0, 0.0, 1.0), 255 };
	}
}
