#pragma once

#include <string>
#include <vector>
#include <fstream>

#include "Definitions.h"
#include "SolidBody.h"


class BSP1Loader : public SolidBody
{

	std::string					fileName;
	std::vector<point3>			vertexContainer;
	std::vector<edge3d>			edgeContainer;
	//std::vector<long>			ledgeContainer;
	std::vector<long>			edgeListContainer;
	std::vector<face_t>			faceContainer;
	std::vector<surface_t>		surfaceContainer;
	std::vector<vert>			idVertices;
	std::vector<int>			idMeshVerts;
	std::vector<face>			idFaces;
	std::vector<triangle3dV>	polyContainer;

	vect3					scale;

public:
	BSP1Loader(std::string);
	BSP1Loader(std::string, vect3);
	~BSP1Loader();

	void			readData();
	int				getTotalVert();
	int				getTotalEdge();
	int				getTotalPoly();
	void			getVertexData(point3*);
	void			calculateTriangles();
	void			getTriangleData_(triangle3dV*);
	vect3			getPosition();
	void			constructShadowVolume(vect3);

	line3d			getLine(unsigned int);
};

