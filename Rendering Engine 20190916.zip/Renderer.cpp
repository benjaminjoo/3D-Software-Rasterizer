#include "Renderer.h"
#include "ShadowVolume.h"
#include <stdio.h>


Renderer::Renderer(Shapes* B, Shapes* A, LightSource* L, Camera* P, EventHandler* E)
{
	Solids			= B;
	Actors			= A;
	Sun				= L;
	Controls		= E;
	Player			= P;
	Entities		= nullptr;

	oldTime			= 0;
	newTime			= 0;
	frameTime		= 0;
	frameCounter	= 0;
	polyCounter		= 0;

	hRatio			= Player->getHRatio();
	vRatio			= Player->getVRatio();

	solidN			= Solids->getNEntities();
	actorN			= Actors->getNEntities();

	solidPolyCount = new int[Solids->getNEntities()];
	Solids->getPolyCountEntities(solidPolyCount);
	actorPolyCount = new int[Actors->getNEntities()];
	Actors->getPolyCountEntities(actorPolyCount);

	solidMesh = new triangle3dV * [solidN];
	for (unsigned int i = 0; i < solidN; i++)
	{
		solidMesh[i] = new triangle3dV[solidPolyCount[i]];
	}
	Solids->getPolyData_(solidN, solidMesh);

	actorMesh = new triangle3dV * [actorN];
	for (unsigned int i = 0; i < actorN; i++)
	{
		actorMesh[i] = new triangle3dV[actorPolyCount[i]];
	}
	Actors->getPolyData_(actorN, actorMesh);

	triangleMesh	= nullptr;
	shadowMesh		= nullptr;

	nShadows		= 0;
	vShadows		= nullptr;

	sunVector		= Sun->getVector();
}


Renderer::~Renderer()
{
	solidN = Solids->getNEntities();
	actorN = Actors->getNEntities();

	for (int i = 0; i < solidN; i++)
	{
		delete[] solidMesh[i];
	}
	delete[] solidMesh;

	for (int i = 0; i < actorN; i++)
	{
		delete[] actorMesh[i];
	}
	delete[] actorMesh;

	//printf("Dynamically allocated memory freed up...\n");
}


void Renderer::updateCameraPosition(double turnH, double turnV, double tiltP, double moveP, double strafeP, double riseP)
{
	Player->azm = -turnH;
	Player->alt = -turnV;
	Player->rol = tiltP;

	Player->x -= moveP * cos(Player->azm) - strafeP * cos(Player->azm + PI * 0.5);
	Player->y += moveP * sin(Player->azm) - strafeP * sin(Player->azm + PI * 0.5);
	Player->z += riseP;
}


bool Renderer::polyFacingLightsource(vect3 v, triangle3dV P)
{
	return (dotProduct(P.N, v) < 0) ? true : false;
}


void Renderer::updateShadowVolumes(model E)
{
	int bodyCount = 0;
	int* polyCount = nullptr;

	nShadows = 0;

	vect3 sunInView;

	transform3d T = Player->getTransformation();
	sunInView = rotZrad(T.sinRol, T.cosRol, rotXrad(T.sinAlt, T.cosAlt, rotZrad(T.sinAzm, T.cosAzm, sunVector)));
	//sunInView = sunVector;

	if (vShadows != nullptr)
	{
		delete[] vShadows;	//printf("-\n");
		vShadows = nullptr;
	}

	switch (E)
	{
	case solid:
		{
			shadowMesh	= solidMesh;
			polyCount	= Solids->getPolyCountEntities();
			Entities	= Solids;
		}
		break;
	case actor:
		{
			shadowMesh	= actorMesh;
			polyCount	= Actors->getPolyCountEntities();
			Entities	= Actors;
		}
		break;
	default:
		{
			shadowMesh	= solidMesh;
			polyCount	= Solids->getPolyCountEntities();
			Entities	= Solids;
		}
		break;
	}

	bodyCount = Entities->getNEntities();

	for (int j = 0; j < bodyCount; j++)
		if (polyCount != nullptr)
			for (int i = 0; i < polyCount[j]; i++)
			{
				triangle3dV tempPoly = Player->world2viewT(T, shadowMesh[j][i]);
				//triangle3dV tempPoly = shadowMesh[j][i];
				if (Entities->assertShadowCasting(j) && this->polyFacingLightsource(sunInView, tempPoly))
					nShadows++;
			}
	vShadows = new ShadowVolume[nShadows];	//printf("+\n");
	int shCount = 0;
	for (int j = 0; j < bodyCount; j++)
	{
		if (polyCount != nullptr)
		{
			for (int i = 0; i < polyCount[j]; i++)
			{
				triangle3dV tempPoly = Player->world2viewT(T, shadowMesh[j][i]);
				//triangle3dV tempPoly = shadowMesh[j][i];
				if (Entities->assertShadowCasting(j) && this->polyFacingLightsource(sunInView, tempPoly))
				{
					if (shCount < nShadows)
					{
						plane tempPlane;

						tempPlane.P = tempPoly.A;
						tempPlane.N = crossProduct(unitVector(subVectors(tempPoly.B, tempPoly.A)), sunInView);
						vShadows[shCount].setPlaneA(tempPlane);

						tempPlane.P = tempPoly.B;
						tempPlane.N = crossProduct(unitVector(subVectors(tempPoly.C, tempPoly.B)), sunInView);
						vShadows[shCount].setPlaneB(tempPlane);

						tempPlane.P = tempPoly.C;
						tempPlane.N = crossProduct(unitVector(subVectors(tempPoly.A, tempPoly.C)), sunInView);
						vShadows[shCount].setPlaneC(tempPlane);

						tempPlane.P = tempPoly.A;
						tempPlane.N = tempPoly.N;
						vShadows[shCount].setPlaneC(tempPlane);
						//printf("Shadow volume no. %d calculated\n", shCount);
						shCount++;
					}
				}
			}
		}
	}

	//printf("%d\t\t%.2f\t%.2f\t%.2f\n", nShadows, sunVector.x, sunVector.y, sunVector.z);

}


void Renderer::updateEntities(model E)
{
	switch (E)
	{
	case solid:
		Entities		= Solids;
		triangleMesh	= solidMesh;
		break;
	case actor:
		Entities		= Actors;
		triangleMesh	= actorMesh;
		break;
	default:
		Entities		= Solids;
		triangleMesh	= solidMesh;
		break;
	}

	if (Entities != nullptr)
	{
		int* polyCount = Entities->getPolyCountEntities();
		
		for (int i = 0; i < Entities->getNEntities(); i++)				//For every entity
		{
			vect3 velocity = Entities->getVelocity(i);
			vect3 angVelocity = Entities->getAngularVelocity(i);
			transformMesh(polyCount[i], triangleMesh[i], 1.0, 1.0, 1.0, velocity.x, velocity.y, velocity.z,
																		angVelocity.x, angVelocity.y, angVelocity.z);
		}
	}
}


void Renderer::renderPoints(int nPoints, point3* Points, Uint32* pixelBuffer)
{
	transform3d playerPosition = Player->getTransformation();
	for (int i = 0; i < nPoints; i++)
	{
		point3 viewP = Player->world2viewP(playerPosition, Points[i]);
		if (Player->insideFrustum(viewP)) { Player->projectPoint(viewP, pixelBuffer, hRatio, vRatio); }
	}
}


void Renderer::renderLines(int nLines, line3d* Lines, Uint32* pixelBuffer, double* depthBuffer)
{
	transform3d playerPosition = Player->getTransformation();
	for (int i = 0; i < nLines; i++)
	{
		line3d viewL = Player->world2viewL(playerPosition, Lines[i]);
		Player->clipToFrustumL(&viewL);
		viewL.colour = Lines[i].colour;
		Player->projectLine(viewL, pixelBuffer, depthBuffer, hRatio, vRatio);
	}
}


void Renderer::renderEntities(model E, Uint32* pixelBuffer, double* depthBuffer)
{
	switch (E)
	{
	case solid:
		Entities		= Solids;
		triangleMesh	= solidMesh;
		break;
	case actor:
		Entities		= Actors;
		triangleMesh	= actorMesh;
		break;
	default:
		Entities		= Solids;
		triangleMesh	= solidMesh;
		break;
	}

	if (Entities != nullptr)
	{
		int* polyCount = Entities->getPolyCountEntities();

		transform3d playerPosition = Player->getTransformation();

		for (int i = 0; i < Entities->getNEntities(); i++)				//For every entity
		{
			int totalPoly = polyCount[i];
			for (int k = 0; k < totalPoly; k++)
			{
				if (Player->polyFacingCamera(triangleMesh[i][k]))		//Backface culling is performed here
				{
					Uint32 colour = triangleMesh[i][k].colour;

					triangle3dV viewT = Player->world2viewT(playerPosition, triangleMesh[i][k]);

					//Player->illuminatePoly(*Sun, &viewT, triangleMesh[i][k], false);
					Player->illuminatePoly(*Sun, &viewT, triangleMesh[i][k], Controls->visualStyle);

					int nVert = Player->clipToFrustum(viewT, Entities->vertexList, Entities->uvList);

					int textureID = triangleMesh[i][k].texture;

					Player->currentTexture = Entities->getTextureData(textureID);

					Player->projectPoly(nVert, Entities->vertexList, Entities->uvList, colour, pixelBuffer, depthBuffer, nShadows, vShadows,
						hRatio, vRatio, Controls->visualStyle, Controls->torchIntensity, Controls->maxIllumination, viewT);

					this->incrementPolyCounter();
				}
			}
		}
	}
}


void Renderer::displayStats(bool crosshair, bool fps, bool position, bool polyN, Canvas Screen)
{
	double azmToShow, altToShow, rolToShow;
	if (crosshair) { Screen.drawCrosshair(2, 6, getColour(0, 127, 127, 127)); }
	if (position)
	{
		//Screen.displayString("AaBbCcDdEeFfGgHhIiJjKkLlMm", 30, 18, getColour(0, 0, 255, 0));
		//Screen.displayString("NnOoPpQqRrSsTtUuVvWwXxYyZz", 30, 16, getColour(0, 0, 255, 0));

		Screen.displayString("MAX ILLUMINATION", 30, 12, getColour(0, 255, 255, 255));
		Screen.displayValue(Controls->maxIllumination, 2, 2, 12, getColour(0, 255, 255, 255));
		Screen.displayString("TORCH INTENSITY", 30, 11, getColour(0, 255, 255, 255));
		Screen.displayValue(Controls->torchIntensity, 2, 2, 11, getColour(0, 255, 255, 255));

		Screen.displayString("POSITION X", 30, 9, getColour(0, 255, 127, 127));
		Screen.displayValue((double)Player->x, 1, 2, 9, getColour(0, 255, 127, 127));
		Screen.displayString("POSITION Y", 30, 8, getColour(0, 127, 255, 127));
		Screen.displayValue((double)Player->y, 1, 2, 8, getColour(0, 127, 255, 127));
		Screen.displayString("POSITION Z", 30, 7, getColour(0, 127, 127, 255));
		Screen.displayValue((double)Player->z, 1, 2, 7, getColour(0, 127, 127, 255));

		azmToShow = Player->azm * 180.0 / PI;
		if (azmToShow > 360.0) { azmToShow -= 360.0; }
		if (azmToShow < -360.0) { azmToShow += 360.0; }
		altToShow = Player->alt * 180.0 / PI - 180.0;
		if (altToShow > 360.0) { altToShow -= 360.0; }
		if (altToShow < -360.0) { altToShow += 360.0; }
		rolToShow = Player->rol * 180.0 / PI;
		if (rolToShow > 360.0) { rolToShow -= 360.0; }
		if (rolToShow < -360.0) { rolToShow += 360.0; }

		Screen.displayString("ROTATION X", 30, 5, getColour(0, 255, 63, 63));
		Screen.displayValue(azmToShow, 1, 2, 5, getColour(0, 255, 63, 63));
		Screen.displayString("ROTATION Y", 30, 4, getColour(0, 63, 255, 63));
		Screen.displayValue(altToShow, 1, 2, 4, getColour(0, 63, 255, 63));
		Screen.displayString("ROTATION Z", 30, 3, getColour(0, 63, 63, 255));
		Screen.displayValue(rolToShow, 1, 2, 3, getColour(0, 63, 63, 255));
	}
	if (fps)
	{
		Screen.displayFps((double)(30000.0 / frameTime), 1, 2, 0);
	}
	if (polyN)
	{
		Screen.displayValue(polyCounter, 1, 30, 18, getColour(0, 255, 0, 0));
	}
}


void Renderer::updateFrameCounter()
{
	frameCounter++;
}


void Renderer::resetPolyCounter()
{
	polyCounter = 0;
}


void Renderer::incrementPolyCounter()
{
	polyCounter++;
}


void Renderer::calculateFrametime()
{
	if (frameCounter == 30)
	{
		oldTime = newTime;
		newTime = clock();
		frameTime = newTime - oldTime;
		frameCounter = 0;
	}
}
