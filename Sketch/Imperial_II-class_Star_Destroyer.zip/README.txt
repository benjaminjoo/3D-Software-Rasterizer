                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1779687
Imperial II-class Star Destroyer by dantesgift is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

The Imperial II-class Star Destroyer, also known as the Imperial II-class Destroyer and colloquially the "ImpStar Deuce", was a Star Destroyer model that was derived from the Imperial I-class Star Destroyer.

Several differences existed between the Imperial I and Imperial II-class Star Destroyer, including the replacement of the tractor beam targeting array between the command tower's sensor globes with a communications tower, as well as the removal of point defense weaponry.

I did not create this model. I converted and repaired this model for printing. credit goes to the following team.

Interregnum Credits

Mod Team
GoaFan77 (Lead Developer)
Ahobgoblin (Apprentice Developer)
ERock72 (Art Lead)

Voice Actors
MiWadiAddiction (Corellian Scout)

Assistants
Sersanara (Maps)
BrutalTheory

Modelers
Evillejedi
Maxloef
ERock72
Warb_Null
Jeroenimo
Suk Munky

Modders from Other Mods
For advice, encouragement and occasional assistance
Lavo of Sins of a Galactic Empire
JasonF of Star Wars: Requiem
ZombiesRus of Sins of the Fallen
Nomada Firefox of Star Wars: Alliance
Maxloef of Star Trek Armada III
Technophobeus/Dul Gukat of Star Trek Armada III
Istaku Mesk of Black Sun: Retribution
Myfist0 of Sacrifice of Angels 2
Psychoak of Sacrifice of Angels 2

Special Thanks

Players/Testers
DarknessDK
Sergeant_Pepper123
Railgunner2160
conran7
Ludo Kreesh
Technophobeus/Dul Gukat

Star Wars Artists
Special thanks to both fan and official Star Wars artists whose work has done so much for the galaxy far far away, including but not limited to...
Ralph McQuarrie
Darren Tan
Viper Aviator

http://www.moddb.com/mods/star-wars-interregnum

http://forums.sinsofasolarempire.com/447324/page/1