================================================================
acid3dm4 - even darker
================================================================

Title			: even darker
Date         		: 15-03-2004
Filename     		: map-acid3dm4.pk3
Author       		: [acid]
Email Address		: acid@planetquake.com
Website			: http://www.planetquake.com/acid
Description		: tdm/ffa/duel map, remake of q1dm6 (the dark place)
Additional Credits to   : id software, the q1 retexturing project and the ppl helping me
			
================================================================

- Play Information -

Players			: 2-x
Bots			: yes
Weapons			: shotgun, 2 rocket launchers, grenade launcher, shaft, plasma

-----------

unzip the the zip file map-acid3dm4.zip into your quake3\baseq3 directory.
start quake3 and either select it from your map list or press tilde to enter the console and type:
"/map acid3dm4" for tdm/ffa/duel
press enter

- Construction -

Base                    : none
Editor(s) used          : q3Radiant202
Known Bugs              : bots enter the "spawn holes"
Build Time              : dunno
Textures used		: id textures, q1 retexturing stuff, modified tely texture by decker
Models used		: none
Compile machine         : tbird 1.4 with 512 megs ddr-ram
q3map compile Time      : the time it takes to make a cup of tea
Brushes     		: dunno

- Copyright / Permissions -
You may not include or distribute this map in/with any sort of commercial product without 
permission from the author.  You may not mass distribute this level via any
non-electronic means, including but not limited to compact disks, and floppy disks
without permission from the author.