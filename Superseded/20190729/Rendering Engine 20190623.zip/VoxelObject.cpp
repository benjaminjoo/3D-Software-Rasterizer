#include "VoxelObject.h"



VoxelObject::VoxelObject()
{
	sizeX		= 10;
	sizeY		= 10;
	sizeZ		= 10;

	voxelBuffer = new Uint32[1000];

	currentX	= 0;
	currentY	= 0;
	currentZ	= 0;

	unit		= 1.0;

	cursorState = 1;
	cursorColour		= 255;
}


VoxelObject::VoxelObject(int sx, int sy, int sz, double a)
{
	sizeX		= sx;
	sizeY		= sy;
	sizeZ		= sz;

	voxelBuffer = new Uint32[sizeX * sizeY * sizeZ];

	currentX	= 0;
	currentY	= 0;
	currentZ	= 0;

	unit		= a;

	cursorState = 1;
	cursorColour = 255;
}


VoxelObject::VoxelObject(int sx, int sy, int sz, int cx, int cy, int cz, double a)
{
	sizeX		= sx;
	sizeY		= sy;
	sizeZ		= sz;

	voxelBuffer = new Uint32[sizeX * sizeY * sizeZ];

	currentX	= cx;
	currentY	= cy;
	currentZ	= cz;

	unit		= a;

	cursorState = 1;
	cursorColour = 255;
}


VoxelObject::~VoxelObject()
{
}


int VoxelObject::getSizeX()
{
	return sizeX;
}


int VoxelObject::getSizeY()
{
	return sizeY;
}


int VoxelObject::getSizeZ()
{
	return sizeZ;
}


int VoxelObject::getCurrentX()
{
	return currentX;
}


int VoxelObject::getCurrentY()
{
	return currentY;
}


int VoxelObject::getCurrentZ()
{
	return currentZ;
}


int VoxelObject::getColour()
{
	return cursorColour;
}


void VoxelObject::stepCurrentX(int step)
{
	currentX += step;
}


void VoxelObject::stepCurrentY(int step)
{
	currentY += step;
}


void VoxelObject::stepCurrentZ(int step)
{
	currentZ += step;
}


void VoxelObject::stepColour(int step)
{
	cursorColour += step;
}


void VoxelObject::setColour(int c)
{
	cursorColour = c;
}


double VoxelObject::getUnitSize()
{
	return unit;
}
