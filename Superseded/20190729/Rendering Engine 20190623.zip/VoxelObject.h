#pragma once

#include "Definitions.h"

class VoxelObject
{
	int		sizeX;
	int		sizeY;
	int		sizeZ;

	int		currentX;
	int		currentY;
	int		currentZ;

	double	unit;
	int		cursorColour;

public:

	Uint32* voxelBuffer;
	char	cursorState;

	VoxelObject();
	VoxelObject(int, int, int, double);
	VoxelObject(int, int, int, int, int, int, double);
	~VoxelObject();

	int getSizeX();
	int getSizeY();
	int getSizeZ();

	int getCurrentX();
	int getCurrentY();
	int getCurrentZ();

	int getColour();

	void stepCurrentX(int);
	void stepCurrentY(int);
	void stepCurrentZ(int);

	void stepColour(int);
	void setColour(int);

	double getUnitSize();
};

