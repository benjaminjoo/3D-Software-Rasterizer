#pragma once
class PaletteMaker
{
public:
	PaletteMaker();
	~PaletteMaker();


};

